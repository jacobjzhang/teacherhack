/*
 *  CSinABox main app code
 */

(function init() {

  function TestSuite() {
    mocha.setup('bdd');

    var results = [];
    describe('heap test', function() {

      var assert = chai.assert;

      var heap = new BinaryHeap(function(x){return x;});

      it('Should have a working .push() function', function() {
        [10, 3, 4, 8, 2, 9, 7, 1, 2, 6, 5].forEach(function (el) {
          heap.push(el)
        });

        assert.equal(heap.content.length, 11);

      });

      it('Should have a working .size() function', function() {
        assert.equal(heap.size(), 11);

      });

      it('Should have a working .pop function', function() {
        var topEl = heap.pop();
        assert.equal(topEl, 1);
      });


      it('Should properly remove element from heap', function() {
        heap.remove(2);

        var numberOfTwos = heap.content.filter(function(item) {
            return item === 2;
          }).length;

        assert.equal(numberOfTwos, 1);

      });

      it('Should return array of popped elements in ascending order', function() {
        while (heap.size() > 0)
          results.push(heap.pop());

        assert.deepEqual(results, [2,3,4,5,6,7,8,9,10]);

      });
    });

    var resultCount = 0;

    var queue = [];
    function animateQueue(msg, clear) {
        queue.push(`$('.card-text #result ul').append('${msg}').addClass('animated fadeIn')`);
    }

    function pushToQueue(msg, clear) {
      queue.push(msg);
    }

    var counter = 0;
    mocha.run()
      .on('test', function(test) {
        counter++;
      })
      .on('test end', function(test) {
        if (test.state === 'passed') {
          pushToQueue(`$('.card-text #result li.counter${counter}').addClass('list-group-item-success')`);
        } else {
          pushToQueue(`$('.card-text #result li.counter${counter}').addClass('list-group-item-danger')`);
        }
      })
      .on('pass', function(test) {
        animateQueue('<li class="list-group-item counter' + counter + '"><span class="tag bg-success label-pill float-xs-right">PASS</span>'+ test.title + '</li>', true);
        resultCount = resultCount + 1;
      })
      .on('fail', function(test, err) {
        animateQueue('<li class="list-group-item counter' + counter + '"><span class="tag bg-danger label-pill float-xs-right">FAIL</span>'+ test.title + '</li>', true);
        animateQueue('<li class="list-group-item counter' + counter + ' list-group-item-danger">' + err + '</li>');

      })
      .on('end', function() {
        animateQueue('<li class="list-group-item">All done</li>');
        displayResults(queue);
      });

    function displayResults(queue) {

      if (resultCount === counter) {
        pushToQueue(`$(".resultText").text("PASSED").addClass("animated headShake infinite");$(".card-footer").removeClass('default-color-dark').addClass('success-color');`, 'clear');
      } else {
        pushToQueue(`$(".resultText").text("FAILED").addClass("animated headShake infinite");$(".card-footer").removeClass('default-color-dark').addClass('danger-color');`, 'clear');
      }

      window.setInterval(function() {

        if (queue.length) {
          var nextFunc = queue.shift();
          var runNext = eval(nextFunc.replace('`', ''));

          runNext.animate({
            opacity: "show"
          });

        }
      }, 500);

    }

  }

  // EVENTS
  window.play_video = function() {
    if (movie._state != 'play') {
      sound.play();
      movie.play();
      function updateSound() {
        $('.card-block button:first .playTime').text('00:' + parseInt(sound.seek()));
      }
      $('.card-block button:first').html('<i class="fa fa-pause" aria-hidden="true"></i><span class="playTime"></span> Pause Lesson');
      window.setInterval(updateSound, 500);
    } else {
      sound.pause();
      movie.pause();
      $('.card-block button:first').html('<i class="fa fa-play" aria-hidden="true"></i> Play Lesson');
    };
  }

  window.remove_hints = function() {
    if (movie._state === 'play') {
      movie.stop()
    };
    EditorClass.removeComments();
  }

  window.get_hint = function() {
    if (movie._state === 'play') {
      movie.stop()
    };

    EditorClass.insertCodeInEditor(finish);
  }

  window.submit_html = function submit_html()
  {
    var editor = EditorClass.getEditor();
    editor.save();

    var code = document.getElementById("editor").value;

    code = code.replace('`', '');

    var s = document.createElement('script');
    s.textContent = code;
    document.body.appendChild(s);
    TestSuite();
    // var data_url = "data:text/html;charset=utf-8;base64," + $.base64.encode(code);
    // document.getElementById("result").src = data_url;
  };

  $(window).scroll(function() {
    if ($(window).scrollTop() > 250) {
      $('.cmExecute').css('top', ($(this).scrollTop()) - 250);
    }
  });



  var EditorClass = {
    'editor' : {},

    'getEditor': function() {
      return this.editor;
    },

    'runEditor' : function (editor) {

      // this.editor = CodeMirror.fromTextArea(document.getElementById("editor"), {
      var movie = CodeMirror.movie('editor');
      this.editor = movie._editor;

      window.movie = movie;
        // firstLineNumber: 0,
        // lineNumbers: true,
        // mode: "javascript",
        // theme: 'elegant',
        // styleActiveLine: true,
        // autoClearEmptyLines: true,
        // foldGutter: true,
        // gutters: ["CodeMirror-linenumbers", "CodeMirror-foldgutter"]
      // });

      this.autoSaveEditor();
      //this.getFiles();

    },

    'autoSaveEditor': function() {
      var editor = this.editor;
      setInterval(function() {
        editor.save();
      }, 6000);
    },

    'insertCodeInEditor': function(response, editor) {
      var preloaded = response.toString();

      this.editor.getDoc().setValue(preloaded);

    },

    'foldCode': function(pos) {
      this.editor.foldCode(
        CodeMirror.Pos(8, 1),
        {rangeFinder: CodeMirror.fold.brace});
    },

    'getFiles': function() {
      // $.get('./binarytree.js', insertCodeInEditor);
      this.insertCodeInEditor(start);

    },

    'jumpToLine': function(lineChar) {
      // this.editor.setCursor(lineChar);
      //this.editor.addSelection(lineChar);
    },

    'searchForTerm': function(query) {
      var cursor = this.editor.getSearchCursor(query, false, true);
      cursor.findNext();
      console.log(lineChar, cursor);
      var lineChar = cursor.from();
      this.jumpToLine(lineChar);
    },

    'removeComments': function() {
      for (var i = 0; i < 2; i++) {
        var cursor = this.editor.getSearchCursor('//', false, false);
        while (cursor) {
          cursor.findNext();
          var lineChar = cursor.from();
          if (lineChar) {
            var thisLine = lineChar.line;
            this.editor.addSelection(lineChar);
            this.editor.execCommand('singleSelection');
            this.editor.execCommand('deleteLine');
          } else {
            break;
          }
        }

      }
    }

  };

  EditorClass.runEditor();

  $('.cmExecute')
    .draggable({
      revert: false,
      snap: 'inner'
    })
    .tooltip({
      animation: true,
      delay: {show: 300, hide: 300}
    });

  setTimeout(EditorClass.searchForTerm('push'), 2000);
  //EditorClass.jumpToLine({line: 11, ch: 1});

  window.editor = EditorClass.editor;

  window.sound = new Howl({
    src: ['./js/binaryHeap.wav']
  });


})();